//JS is dynamically typed
/*const student={
    fullName:"shubham",
    age:20,
    cgpa:8,
    isPass:true,
};
student ["age"]=student ["age"]+1;
console.log(student.age);*/
/*const product=
{
    itemName:"Parker Ball Pen",
    review:7002,
    rating:4,
    discount:5,
    price:270,
};
console.log(product)*/

const profile={
    nameOfUser:"shubham sutar",
    isFollow:true,
    post:195,
    followers:50000,
};
console.log(profile);