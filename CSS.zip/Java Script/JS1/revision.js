// console.log("hello world!")
// console.log('hello ');
// {
//     let age=23;
//     age=45;
//     console.log(age);
// }

// const age=20;
// age=34;
// console.log(age);

const profile1={
    userName:"shubham",
    post:109,
    followers:1203,
    following:231,
};
console.log(profile1)