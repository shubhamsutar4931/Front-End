//if statement

/*let age=16;

if(age>18)
{
    console.log("You can vote.");
}
if(age<18)
{
    console.log("You can not vote.");
}*/
/*let mode="dark";
let color;
 if(mode=="dark")
 {
    color="black";
 }
 if(mode=="light")
 {
    color="white";
 }
 console.log(color);*/


 //if-else statement

 /*let mode="dark";
let color;
 if(mode=="dark")
 {
    color="black";
 }
else
 {
    color="white";
 }
 console.log(color);*/
 
 /*let num=10;
  
 if(num%2===0)
 {
    console.log(num," is even");
 }
 else
 {
    console.log(num," is odd");
 }*/

 //else-if statement
 /*let age=14;

 if(age<18)
 {
   console.log("Junior");
 }
 else if(age>60)
 {
   console.log("Senior");
 }
 else
 {
   console.log("Middle");
 }*/

 //ternary operator

//  let mode="dark";
//  let color;

//  color="dark"?console.log("black"):console.log("white");
// let age=20;
// age>18?console.log("eligible for vote"):console.log("not eligible");


//practice Q1
/*let num=prompt("Enter a number");
if(num%5===0)
{
   console.log(num,"Multiple of 5");
}
else{
   console.log(num,"Not Multiple of 5");
}*/


//practice Q2
// let marks=prompt("Enter marks");
// let grade;

// if(marks>=80 && marks<99)
// {
//    grade="A";
// }
// else if(marks>=70 && marks<=79)
// {
//    grade="B";
// }
// else if(marks>=60 && marks<=69)
// {
//    grade="C";
// }
// else if(marks>=50 && marks<=59)
// {
//    grade="D";
// }
// else(marks>=0 && marks<=49)
// {
//    grade="E";
// }
// console.log("according to your marks grade =",grade);