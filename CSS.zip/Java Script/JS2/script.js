//Arithmatic operations
// let a=3;
// let b=2;
/*console.log("a=",a , "& b=",b);
console.log("a+b=",a+b);
console.log("a-b=",a-b);
console.log("a*b=",a*b);
console.log("a/b=",a/b);
console.log("a%b=",a%b);
console.log("a**b=",a**b);*/
//unary operator

// a++,
// ++b
/*console.log("a=",a++, "& b=",b++);
console.log("a++=",a, "& ++b=",b);
console.log("a--=",-- a, "& b--=",--b);*/

//assignment operators
// console.log("a++=",a++);
// console.log("a=",a);
/*let a=5;
let b=2;
//a+=4;
b-=2;
//a*=4;
//a/=2;
//a%=2;
a**=3;
console.log("a=",a);
console.log("b=",b);*/

//Comparison operator
/*let a=5;
let b=5;
console.log("a>b",a>b);*/

//logical operator
let a=5;
let b=6;
let cond1=a<b;
let cond2=b>a;
console.log("cond1=",cond1&&cond2);


