// for(let i=1;i<=5;i++)
// {
//     console.log("Hello world!");
// }

// for(let i=1;i<=5;i++)
//  {
//      console.log("i=",i);
//  }
//  console.log(i);

//calculate sum of 1 to n
// let sum=0;
// let n=10;
// for(let i=1;i<=n;i++){
//     sum=sum+i;
// }
// console.log(sum);

//while loop
 
// let i=1;
// while(i<=10)
// {
//     console.log("hello world");
//     i++;
// }

//do-while loop
// let i=20;
// do{
//     console.log("hello world");
//     i++;
// }while(i<=5);

//for-of loop using for string &array
// let str="helloWorld";
// let size=0;
// for(let i of str)
// {
//     console.log("i=",i);
//     size++;
// }
// console.log("string size=",size);

//for-in loop using for objects

//  let student=
// {
//     name:"shubham",
//     age:20,
//     prn:33,
//     isPass:true
//  };
//  for(let i in student)
//  {
//      console.log("i=",i,"value=",student[i]);
//  }


//practice Q1
// let i=0;
// for(let i=0;i<=100;i++)
// {
//     if(i%2==0)
//    {
//     console.log(i);
//    }
// }

//practice Q2
// let game_no=22;
// let num=prompt("Guess the game number:");
// while(num!=game_no){
//     let num=prompt("you entered wrong no,Guess the number");
// }
// console.log("congrats your enter right no");

//string
//inmutable=it not change
// let str="shubhamsutar";
// let str2='shubham';
// console.log(str.length);
// console.log(str[10]);

// template literals
// let specialstring=`This is template literals ${1+2+3}`;
//  console.log(specialstring);

// comparion string and template literals
// let obj={
//     item:"soap",
//     price:20
// };
// console.log("the cost of",obj.item,"is ",obj.price,"rupees");
// let output=`the cost of ${obj.item} is ${obj.price} rupees`;
// console.log(output);


// string methods

// tab
// console.log("shubham\nsutar");
// console.log("shubham\tsutar");
//  let str="shubham sutar";
//  let str1=" RIT college";
//  console.log(str.toUpperCase());
//  console.log(str1.toLowerCase());
//  console.log(str.trim());
//  console.log(str.slice(5,9));
// let res="i am learning "+str+str1;
// console.log(res)
// console.log(str.concat(str1));
// console.log(str.replaceAll("h","y"));
// console.log(str.charAt(0));


//practice Q3
// let username = prompt("Enter full name");
// console.log("@"+username+username.length );



